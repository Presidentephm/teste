import { useCart } from "./CartContext";

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CartDrawer({ isOpen, onClose }: CartDrawerProps) {
  const { items, removeFromCart, addToCart, totalItems, totalPrice } = useCart();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-end">
      <div className="cart-drawer open">
        <div className="cart-header">
          <h2 className="text-xl font-bold">Seu Carrinho</h2>
          <button 
            onClick={onClose}
            className="cart-close"
            aria-label="Fechar carrinho"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>

        <div className="cart-items">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64">
              <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-400 mb-4">
                <circle cx="9" cy="21" r="1"></circle>
                <circle cx="20" cy="21" r="1"></circle>
                <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
              </svg>
              <p className="text-gray-500">Seu carrinho está vazio</p>
              <button 
                onClick={onClose}
                className="mt-4 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
              >
                Continuar Comprando
              </button>
            </div>
          ) : (
            <>
              {items.map((item) => (
                <div key={item.id} className="cart-item">
                  <div className="cart-item-image-container">
                    <img 
                      src={item.imagem || `https://source.unsplash.com/random/80x80/?${encodeURIComponent(item.nome)},medicine`} 
                      alt={item.nome}
                      className="cart-item-image"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://via.placeholder.com/80x80?text=Produto';
                      }}
                    />
                  </div>
                  <div className="cart-item-info">
                    <h3 className="cart-item-name">{item.nome}</h3>
                    <p className="cart-item-price">
                      {item.preco.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </p>
                    <div className="cart-item-quantity">
                      <button 
                        onClick={() => removeFromCart(item.id)}
                        className="quantity-button"
                      >
                        -
                      </button>
                      <span className="quantity-value">{item.quantidade}</span>
                      <button 
                        onClick={() => addToCart(item)}
                        className="quantity-button"
                      >
                        +
                      </button>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">
                      {(item.preco * item.quantidade).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </p>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>
        
        {items.length > 0 && (
          <div className="cart-footer">
            <div className="cart-total">
              <span>Total ({totalItems} {totalItems === 1 ? 'item' : 'itens'})</span>
              <span>{totalPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
            </div>
            <button className="checkout-button">
              Finalizar Compra
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
