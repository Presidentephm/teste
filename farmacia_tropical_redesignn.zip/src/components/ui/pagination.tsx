import React from "react";
import "./pagination.css";

interface PaginationProps extends React.ComponentProps<"nav"> {}

export function Pagination({ className, ...props }: PaginationProps) {
  return (
    <nav className={`pagination ${className || ""}`} {...props} />
  );
}

interface PaginationContentProps extends React.ComponentProps<"ul"> {}

export function PaginationContent({ className, ...props }: PaginationContentProps) {
  return (
    <ul className={`pagination-content ${className || ""}`} {...props} />
  );
}

interface PaginationItemProps extends React.ComponentProps<"li"> {}

export function PaginationItem({ className, ...props }: PaginationItemProps) {
  return (
    <li className={`pagination-item ${className || ""}`} {...props} />
  );
}

interface PaginationLinkProps extends React.ComponentProps<"a"> {
  isActive?: boolean;
}

export function PaginationLink({ className, isActive, ...props }: PaginationLinkProps) {
  return (
    <a
      className={`pagination-link ${className || ""}`}
      {...(isActive && { "data-active": true })}
      {...props}
    />
  );
}

interface PaginationPreviousProps extends React.ComponentProps<"a"> {}

export function PaginationPrevious({ className, ...props }: PaginationPreviousProps) {
  return (
    <a
      className={`pagination-previous ${className || ""}`}
      {...props}
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="16"
        height="16"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="mr-2 h-4 w-4"
      >
        <path d="M15 18l-6-6 6-6" />
      </svg>
      <span>Anterior</span>
    </a>
  );
}

interface PaginationNextProps extends React.ComponentProps<"a"> {}

export function PaginationNext({ className, ...props }: PaginationNextProps) {
  return (
    <a
      className={`pagination-next ${className || ""}`}
      {...props}
    >
      <span>Próximo</span>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="16"
        height="16"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="ml-2 h-4 w-4"
      >
        <path d="M9 18l6-6-6-6" />
      </svg>
    </a>
  );
}

interface PaginationEllipsisProps extends React.ComponentProps<"span"> {}

export function PaginationEllipsis({ className, ...props }: PaginationEllipsisProps) {
  return (
    <span
      className={`pagination-ellipsis ${className || ""}`}
      {...props}
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="16"
        height="16"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="h-4 w-4"
      >
        <circle cx="12" cy="12" r="1" />
        <circle cx="19" cy="12" r="1" />
        <circle cx="5" cy="12" r="1" />
      </svg>
    </span>
  );
}
