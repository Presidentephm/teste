import { useCart } from "./CartContext";

interface HeaderProps {
  onCartClick: () => void;
}

export function Header({ onCartClick }: HeaderProps) {
  const { totalItems, totalPrice } = useCart();

  return (
    <div>
      {/* Barra superior */}
      <div className="header">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between py-2">
            {/* Logo e nome */}
            <div className="logo-container mb-4 md:mb-0">
              <img src="/logo.png" alt="Farmácia Tropical" className="logo" />
              <div className="ml-2">
                <h1 className="brand-name">Farmácia Tropical</h1>
                <p className="brand-slogan">Sua saúde em boas mãos</p>
              </div>
            </div>
            
            {/* Barra de busca */}
            <div className="w-full md:w-2/5 mb-4 md:mb-0">
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="O que você procura hoje?" 
                  className="search-bar"
                />
                <button className="search-button absolute right-0 top-0 h-full">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                  </svg>
                </button>
              </div>
            </div>
            
            {/* Botões de usuário e carrinho */}
            <div className="flex items-center space-x-4">
              <button className="flex items-center text-white">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                  <circle cx="12" cy="7" r="4"></circle>
                </svg>
                <span>Entrar</span>
              </button>
              
              <button 
                className="flex items-center text-white"
                onClick={onCartClick}
              >
                <div className="cart-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="9" cy="21" r="1"></circle>
                    <circle cx="20" cy="21" r="1"></circle>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                  </svg>
                  {totalItems > 0 && (
                    <span className="cart-badge">{totalItems}</span>
                  )}
                </div>
                <div className="ml-2">
                  <div className="text-xs">Carrinho</div>
                  <div className="font-bold">{totalPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</div>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Navegação por categorias */}
      <nav className="nav-categories">
        <div className="container mx-auto px-4">
          <div className="flex overflow-x-auto space-x-4">
            <a href="#" className="category-tab medicamentos">
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                  <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                  <line x1="12" y1="8" x2="12" y2="16"></line>
                  <line x1="8" y1="12" x2="16" y2="12"></line>
                </svg>
                Medicamentos
              </div>
            </a>
            <a href="#" className="category-tab dermocosmeticos">
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                  <path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5z"></path>
                  <line x1="16" y1="8" x2="2" y2="22"></line>
                  <line x1="17.5" y1="15" x2="9" y2="15"></line>
                </svg>
                Dermocosméticos
              </div>
            </a>
            <a href="#" className="category-tab higiene">
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                  <polyline points="16 17 21 12 16 7"></polyline>
                  <line x1="21" y1="12" x2="9" y2="12"></line>
                </svg>
                Higiene e Beleza
              </div>
            </a>
            <a href="#" className="category-tab bebe">
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                  <path d="M16 16v1a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2m5.66 0H14a2 2 0 0 1 2 2v3.34"></path>
                </svg>
                Mamãe e Bebê
              </div>
            </a>
            <a href="#" className="category-tab saude">
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                  <path d="M22 12h-4l-3 9L9 3l-3 9H2"></path>
                </svg>
                Saúde e Bem-estar
              </div>
            </a>
            <a href="#" className="category-tab ofertas">
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                  <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                </svg>
                Ofertas
              </div>
            </a>
          </div>
        </div>
      </nav>
    </div>
  );
}
