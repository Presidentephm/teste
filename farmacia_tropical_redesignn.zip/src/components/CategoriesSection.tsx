export function CategoriesSection() {
  const categories = [
    {
      id: 1,
      name: 'Medicamentos',
      image: 'https://source.unsplash.com/random/300x200/?medicine,pills',
      color: '#00A859'
    },
    {
      id: 2,
      name: 'Dermocosméticos',
      image: 'https://source.unsplash.com/random/300x200/?cosmetics,skincare',
      color: '#0099CC'
    },
    {
      id: 3,
      name: 'Higiene e Beleza',
      image: 'https://source.unsplash.com/random/300x200/?beauty,hygiene',
      color: '#E83E8C'
    },
    {
      id: 4,
      name: 'Mamãe e Bebê',
      image: 'https://source.unsplash.com/random/300x200/?baby,mother',
      color: '#FFC107'
    },
    {
      id: 5,
      name: 'Saúde e Bem-estar',
      image: 'https://source.unsplash.com/random/300x200/?health,wellness',
      color: '#6F42C1'
    },
    {
      id: 6,
      name: 'Ofertas',
      image: 'https://source.unsplash.com/random/300x200/?sale,discount',
      color: '#FF3B30'
    }
  ];

  return (
    <div className="my-12">
      <h2 className="text-2xl font-bold mb-6">Categorias Populares</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {categories.map(category => (
          <a 
            href="#" 
            key={category.id} 
            className="block rounded-lg overflow-hidden shadow-md transition-transform hover:transform hover:scale-105"
          >
            <div className="relative h-32">
              <img 
                src={category.image} 
                alt={category.name} 
                className="w-full h-full object-cover"
              />
              <div 
                className="absolute inset-0 opacity-60"
                style={{ backgroundColor: category.color }}
              ></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <h3 className="text-white text-lg font-bold text-center px-2">{category.name}</h3>
              </div>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
}
