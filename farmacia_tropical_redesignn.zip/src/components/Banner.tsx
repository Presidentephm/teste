import { useState } from 'react';

interface BannerProps {}

export function Banner({}: BannerProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const banners = [
    {
      id: 1,
      image: 'https://source.unsplash.com/random/1200x400/?pharmacy,medicine',
      alt: 'Promoções especiais na Farmácia Tropical',
      title: 'Ofertas Imperdíveis',
      subtitle: 'Até 40% de desconto em medicamentos selecionados'
    },
    {
      id: 2,
      image: 'https://source.unsplash.com/random/1200x400/?cosmetics',
      alt: 'Linha de dermocosméticos',
      title: 'Cuide da sua pele',
      subtitle: 'Produtos dermatológicos com preços especiais'
    },
    {
      id: 3,
      image: 'https://source.unsplash.com/random/1200x400/?baby,products',
      alt: 'Produtos para bebês',
      title: 'Semana do Bebê',
      subtitle: 'Tudo para o cuidado do seu pequeno'
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev === banners.length - 1 ? 0 : prev + 1));
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? banners.length - 1 : prev - 1));
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  return (
    <div className="banner-section relative">
      <div className="container mx-auto px-4">
        <div className="relative overflow-hidden rounded-lg">
          {banners.map((banner, index) => (
            <div 
              key={banner.id}
              className={`relative transition-opacity duration-500 ${
                index === currentSlide ? 'opacity-100' : 'opacity-0 absolute inset-0'
              }`}
            >
              <img 
                src={banner.image} 
                alt={banner.alt}
                className="w-full h-64 md:h-96 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent flex flex-col justify-center px-8 md:px-16">
                <h2 className="text-white text-2xl md:text-4xl font-bold mb-2">{banner.title}</h2>
                <p className="text-white text-lg md:text-xl mb-4">{banner.subtitle}</p>
                <button className="bg-yellow-400 text-gray-800 font-bold py-2 px-6 rounded-md w-max hover:bg-yellow-500 transition-colors">
                  Ver ofertas
                </button>
              </div>
            </div>
          ))}
          
          {/* Controles de navegação */}
          <button 
            onClick={prevSlide}
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/30 hover:bg-white/50 rounded-full p-2 text-white"
            aria-label="Slide anterior"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="15 18 9 12 15 6"></polyline>
            </svg>
          </button>
          
          <button 
            onClick={nextSlide}
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/30 hover:bg-white/50 rounded-full p-2 text-white"
            aria-label="Próximo slide"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="9 18 15 12 9 6"></polyline>
            </svg>
          </button>
          
          {/* Indicadores */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
            {banners.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-3 h-3 rounded-full ${
                  index === currentSlide ? 'bg-white' : 'bg-white/50'
                }`}
                aria-label={`Ir para slide ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
