import { useState, useEffect } from 'react';
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from './ui/pagination';
import { useCart } from './CartContext';

interface Product {
  id: string;
  nome: string;
  preco: number;
  imagem?: string;
}

export default function ProductList() {
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [loadingImages, setLoadingImages] = useState<Record<string, boolean>>({});
  const productsPerPage = 8;
  
  const { addToCart } = useCart();

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch('/produtos.json');
        const data = await response.json();
        setFilteredProducts(data);
        setLoading(false);
      } catch (error) {
        console.error('Erro ao carregar produtos:', error);
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  // Função para buscar imagem para um produto
  const fetchProductImage = async (product: Product) => {
    if (loadingImages[product.id]) return;
    
    setLoadingImages(prev => ({ ...prev, [product.id]: true }));
    
    try {
      const searchTerm = product.nome.split(' ')[0]; // Usa a primeira palavra do nome do produto
      
      // Usando diretamente o serviço de imagens aleatórias do Unsplash com o termo de busca
      const imageUrl = `https://source.unsplash.com/random/300x200/?${encodeURIComponent(searchTerm)},medicine`;
      
      setFilteredProducts(currentProducts => 
        currentProducts.map(p => 
          p.id === product.id ? { ...p, imagem: imageUrl } : p
        )
      );
    } catch (error) {
      console.error('Erro ao buscar imagem:', error);
    } finally {
      setLoadingImages(prev => ({ ...prev, [product.id]: false }));
    }
  };

  // Cálculo para paginação
  const indexOfLastProduct = currentPage * productsPerPage;
  const indexOfFirstProduct = indexOfLastProduct - productsPerPage;
  const currentProducts = filteredProducts.slice(indexOfFirstProduct, indexOfLastProduct);
  const totalPages = Math.ceil(filteredProducts.length / productsPerPage);

  // Função para gerar links de paginação
  const generatePaginationLinks = () => {
    const links = [];
    const maxVisiblePages = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

    if (endPage - startPage + 1 < maxVisiblePages) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
      links.push(
        <PaginationItem key={i}>
          <PaginationLink
            onClick={() => setCurrentPage(i)}
            isActive={i === currentPage}
          >
            {i}
          </PaginationLink>
        </PaginationItem>
      );
    }
    return links;
  };

  // Formatação de preço em reais
  const formatPrice = (price: number) => {
    return price.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    });
  };

  // Efeito para carregar imagens dos produtos atuais
  useEffect(() => {
    currentProducts.forEach(product => {
      if (!product.imagem && !loadingImages[product.id]) {
        fetchProductImage(product);
      }
    });
  }, [currentProducts]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto"></div>
          <p className="mt-4 text-lg">Carregando produtos...</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {currentProducts.map((product) => (
          <div key={product.id} className="product-card">
            {/* Badge de desconto (simulado para alguns produtos) */}
            {product.id.charAt(0) > '5' && (
              <div className="discount-badge">
                {Math.floor(Math.random() * 30) + 10}% OFF
              </div>
            )}
            
            {/* Imagem do produto */}
            <div className="relative">
              {product.imagem ? (
                <img 
                  src={product.imagem} 
                  alt={product.nome}
                  className="product-image"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://via.placeholder.com/300x200?text=Farmácia+Tropical';
                  }}
                />
              ) : (
                <div className="product-image flex items-center justify-center">
                  <div className="animate-pulse w-8 h-8 border-4 border-green-600 border-t-transparent rounded-full"></div>
                </div>
              )}
            </div>
            
            {/* Informações do produto */}
            <div className="product-info">
              <p className="text-sm text-gray-500 mb-1">Código: {product.id}</p>
              <h3 className="product-name">{product.nome}</h3>
              
              <div className="mt-auto">
                {/* Preço anterior simulado para produtos com desconto */}
                {product.id.charAt(0) > '5' && (
                  <div className="product-old-price">
                    {formatPrice(product.preco * 1.3)}
                  </div>
                )}
                
                <div className="product-price">
                  {formatPrice(product.preco)}
                </div>
                
                <button 
                  className="add-button w-full"
                  onClick={() => addToCart(product)}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                    <circle cx="9" cy="21" r="1"></circle>
                    <circle cx="20" cy="21" r="1"></circle>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                  </svg>
                  Adicionar
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {totalPages > 1 && (
        <Pagination className="mt-8">
          <PaginationContent>
            <PaginationItem>
              <PaginationPrevious
                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                className={currentPage === 1 ? 'pointer-events-none opacity-50' : ''}
              />
            </PaginationItem>
            
            {generatePaginationLinks()}
            
            <PaginationItem>
              <PaginationNext
                onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                className={currentPage === totalPages ? 'pointer-events-none opacity-50' : ''}
              />
            </PaginationItem>
          </PaginationContent>
        </Pagination>
      )}
    </div>
  );
}
