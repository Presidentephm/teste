import { createContext, useContext, useState } from 'react';

interface CartItem {
  id: string;
  nome: string;
  preco: number;
  quantidade: number;
  imagem?: string;
}

interface CartContextType {
  items: CartItem[];
  addToCart: (product: { id: string; nome: string; preco: number }) => void;
  removeFromCart: (id: string) => void;
  clearCart: () => void;
  totalItems: number;
  totalPrice: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);

  const addToCart = (product: { id: string; nome: string; preco: number }) => {
    setItems(currentItems => {
      // Verificar se o produto já está no carrinho
      const existingItemIndex = currentItems.findIndex(item => item.id === product.id);
      
      if (existingItemIndex > -1) {
        // Se o produto já existe, aumentar a quantidade
        const updatedItems = [...currentItems];
        updatedItems[existingItemIndex] = {
          ...updatedItems[existingItemIndex],
          quantidade: updatedItems[existingItemIndex].quantidade + 1
        };
        return updatedItems;
      } else {
        // Se o produto não existe, adicionar ao carrinho
        return [...currentItems, { ...product, quantidade: 1 }];
      }
    });
  };

  const removeFromCart = (id: string) => {
    setItems(currentItems => {
      const existingItemIndex = currentItems.findIndex(item => item.id === id);
      
      if (existingItemIndex > -1) {
        const item = currentItems[existingItemIndex];
        
        // Se a quantidade for 1, remover o item
        if (item.quantidade === 1) {
          return currentItems.filter(item => item.id !== id);
        }
        
        // Caso contrário, diminuir a quantidade
        const updatedItems = [...currentItems];
        updatedItems[existingItemIndex] = {
          ...item,
          quantidade: item.quantidade - 1
        };
        return updatedItems;
      }
      
      return currentItems;
    });
  };

  const clearCart = () => {
    setItems([]);
  };

  // Calcular o total de itens
  const totalItems = items.reduce((total, item) => total + item.quantidade, 0);
  
  // Calcular o preço total
  const totalPrice = items.reduce((total, item) => total + (item.preco * item.quantidade), 0);

  return (
    <CartContext.Provider value={{ 
      items, 
      addToCart, 
      removeFromCart, 
      clearCart, 
      totalItems,
      totalPrice
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
