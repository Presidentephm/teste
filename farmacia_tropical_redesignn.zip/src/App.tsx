import ProductList from "./components/ProductList";
import { Header } from "./components/Header";
import { CartProvider } from "./components/CartContext";
import { useState } from "react";
import { CartDrawer } from "./components/CartDrawer";
import { Banner } from "./components/Banner";
import { ServicesSection } from "./components/ServicesSection";
import { CategoriesSection } from "./components/CategoriesSection";
import { Footer } from "./components/Footer";

function App() {
  const [isCartOpen, setIsCartOpen] = useState(false);

  const openCart = () => setIsCartOpen(true);
  const closeCart = () => setIsCartOpen(false);

  return (
    <CartProvider>
      <div className="min-h-screen flex flex-col">
        <Header onCartClick={openCart} />
        <main className="flex-grow">
          <Banner />
          <div className="container mx-auto px-4 py-6">
            <ServicesSection />
            <div className="my-8">
              <h2 className="text-2xl font-bold mb-4">Ofertas Especiais</h2>
              <ProductList />
            </div>
            <CategoriesSection />
          </div>
        </main>
        <Footer />
        <CartDrawer isOpen={isCartOpen} onClose={closeCart} />
      </div>
    </CartProvider>
  );
}

export default App;
